export class Flight {


  carrierName: string;
  flightModel: string;
  seatCapacity: number;
  flightNumber: string;

  constructor() { }
}
