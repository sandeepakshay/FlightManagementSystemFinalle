import { Airport } from './airport';
import { Timestamp } from 'rxjs';
import { Time } from '@angular/common';
import { Flight } from './flight';

export class Schedule {

  scheduleId: number;
  sourceAirport: Airport;
  destinationAirport: Airport;
  arrivalTime: number;
  departureTime: number;
  flight: Flight;
  availableSeats: number;
  ticketCost: number;


}
