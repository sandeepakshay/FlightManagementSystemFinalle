import { ScheduledFlight } from './scheduled-flight';

describe('ScheduledFlight', () => {
  it('should create an instance', () => {
    expect(new ScheduledFlight()).toBeTruthy();
  });
});
