import { Search } from './search';

describe('Search', () => {
  it('should create an instance', () => {
    expect(new Search()).toBeTruthy();
  });
});
