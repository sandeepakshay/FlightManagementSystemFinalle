import { Airport } from './airport';

export class Search {

  sourceAirport:Airport;
  DeparturTime:string;
  destinationAirport:Airport;
}
