export class Users {

   UserId:number;

	 UserPhone:number;


	 UserType:string;


  UserName:string;


	 password:string;


	email:string;
}
